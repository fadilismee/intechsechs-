import Img1 from "../assets/pics/88.jpg";
import Img2 from "../assets/pics/67.jpg";
import Img3 from "../assets/pics/23.jpg";
import Img4 from "../assets/pics/24.jpg";
import Img5 from "../assets/pics/35.jpg";
import Img6 from "../assets/pics/36.jpg";
import Img7 from "../assets/pics/37.jpg";
import Img8 from "../assets/pics/7.jpeg";
import Img9 from "../assets/pics/10.jpeg";
import Img10 from "../assets/pics/11.jpeg";
import Img11 from "../assets/pics/12.jpeg";
import Img12 from "../assets/pics/13.jpeg";

export const images = [
  {
    src: Img1,
  },
  {
    src: Img2,
  },
  {
    src: Img3,
  },
  {
    src: Img4,
  },
  {
    src: Img5,
  },
  {
    src: Img6,
  },
  {
    src: Img7,
  },
];
